/*
 * @(#)XAQueueSession.java	1.8 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** An XAQueueSession provides a regular QueueSession which can be used to
  * create QueueReceivers, QueueSenders and QueueBrowsers (optional).
  *
  * @version     1.0 - 13 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.XASession
  */

public interface XAQueueSession extends XASession {

    /** Get the queue session associated with this XAQueueSession.
      *  
      * @return the queue session object.
      *  
      * @exception JMSException if a JMS error occurs.
      */ 
 
    QueueSession
    getQueueSession() throws JMSException;
}
