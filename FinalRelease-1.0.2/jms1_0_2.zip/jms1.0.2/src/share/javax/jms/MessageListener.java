/*
 * @(#)MessageListener.java	1.11 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;


/** A MessageListener is used to receive asynchronously delivered
  * messages.
  *
  * <P>Each session must insure that it passes messages serially to the
  * listener. This means that a listener assigned to one or more consumers
  * of the same session can assume that the onMessage method 
  * is not called with the next message until the session has completed the 
  * last call.
  *
  * @version     1.0 - 13 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  */

public interface MessageListener {

    /** Pass a message to the Listener.
      *
      * @param message the message passed to the listener.
      */

    void 
    onMessage(Message message);
}
