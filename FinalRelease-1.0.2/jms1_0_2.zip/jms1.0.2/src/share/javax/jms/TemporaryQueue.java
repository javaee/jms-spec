/*
 * @(#)TemporaryQueue.java	1.10 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** A TemporaryQueue is a unique Queue object created for the duration of a
  * QueueConnection. It is a system defined queue that can only be consumed 
  * by the QueueConnection that created it.
  *
  * @version     1.0 - 9 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see QueueSession#createTemporaryQueue()
  */

public interface TemporaryQueue extends Queue {

    /** Delete this temporary queue. If there are still existing senders 
      * or receivers still using it, then a JMSException will be thrown.
      *  
      * @exception JMSException if JMS implementation fails to delete a 
      *                         Temporary topic due to some internal error.
      */

    void 
    delete() throws JMSException; 
}
