/*
 * @(#)Connection.java	1.15 99/11/05
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** A JMS Connection is a client's active connection to its JMS provider. 
  * It will typically allocate provider resources outside the Java virtual 
  * machine.
  *
  * <P>Connections support concurrent use.
  *
  * <P>A Connection serves several purposes:
  *
  * <UL>
  *   <LI>It encapsulates an open connection with a JMS provider. It 
  *       typically represents an open TCP/IP socket between a client and 
  *       a provider service daemon.
  *   <LI>Its creation is where client authenticating takes place.
  *   <LI>It can specify a unique client identifier.
  *   <LI>It provides ConnectionMetaData.
  *   <LI>It supports an optional ExceptionListener.
  * </UL>
  *
  * <P>Due to the authentication and communication setup done when a 
  * Connection is created, a Connection is a relatively heavy-weight JMS 
  * object. Most clients will do all their messaging with a single Connection.
  * Other more advanced applications may use several Connections. JMS does 
  * not architect a reason for using multiple connections; however, there may 
  * be operational reasons for doing so.
  *
  * <P>A JMS client typically creates a Connection; one or more Sessions; 
  * and a number of message producers and consumers. When a Connection is 
  * created it is in stopped mode. That means that no messages are being 
  * delivered.
  *
  * <P>It is typical to leave the Connection in stopped mode until setup 
  * is complete. At that point the Connection's start() method is called 
  * and messages begin arriving at the Connection's consumers. This setup 
  * convention minimizes any client confusion that may result from 
  * asynchronous message delivery while the client is still in the process 
  * of setting itself up.
  *
  * <P>A Connection can immediately be started and the setup can be done 
  * afterwards. Clients that do this must be prepared to handle asynchronous 
  * message delivery while they are still in the process of setting up.
  *
  * <P>A message producer can send messages while a Connection is stopped.
  *
  * @version     1.0 - 3 August 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.ConnectionFactory
  * @see         javax.jms.QueueConnection
  * @see         javax.jms.TopicConnection
  */

public interface Connection {

    /** Get the client identifier for this connection.
      *  
      * This value is JMS Provider specific.
      * Either pre-configured by an administrator in a ConnectionFactory
      * or assigned dynamically by the application by calling
      * <code>setClientID</code> method.
      * 
      * 
      * @return the unique client identifier.
      *  
      * @exception JMSException if JMS implementation fails to return
      *                         the client ID for this Connection due
      *                         to some internal error.
      *
      **/
    String
    getClientID() throws JMSException;


    /** Set the client identifier for this connection.
      *  
      * <P>The preferred way to assign a Client's client identifier is for 
      * it to be configured in a client-specific ConnectionFactory and 
      * transparently assigned to the Connection it creates. 
      * 
      * <P>Alternatively, a client can set a connection's client identifier
      * using a provider-specific value. The facility to explicitly set a
      * connection's client identifier is not a mechanism for overriding the
      * identifier that has been administratively configured. It is provided
      * for the case where no administratively specified identifier exists. 
      * If one does exist, an attempt to change it by setting it must throw a
      * IllegalStateException. If a client explicitly does the set it must do
      * this immediately after creating the connection and before any other
      * action on the connection is taken. After this point, setting the
      * client identifier is a programming error that should throw an
      * IllegalStateException.
      *
      * <P>The purpose of client identifier is to associate a connection and 
      * its objects with a state maintained on behalf of the client by a 
      * provider. The only such state identified by JMS is that required 
      * to support durable subscriptions
      *
      *
      * <P>If another connection with <code>clientID</code> is already running when
      * this method is called, the JMS Provider should detect the duplicate id and throw 
      * InvalidClientIDException.
      *
      * @param clientID the unique client identifier
      *  
      * @exception JMSException general exception if JMS implementation fails to
      *                         set the client ID for this Connection due
      *                         to some internal error.
      *
      * @exception InvalidClientIDException if JMS client specifies an
      *                         invalid or duplicate client id.
      * @exception IllegalStateException if attempting to set
      *       a connection's client identifier at the wrong time or 
      *       when it has been administratively configured.
      */

    void
    setClientID(String clientID) throws JMSException;

 
    /** Get the meta data for this connection.
      *  
      * @return the connection meta data.
      *  
      * @exception JMSException general exception if JMS implementation fails to
      *                         get the Connection meta-data for this Connection.
      *
      * @see javax.jms.ConnectionMetaData
      */

    ConnectionMetaData
    getMetaData() throws JMSException;

    /**
     * Get the ExceptionListener for this Connection.
     *
     * @return the ExceptionListener for this Connection. 
     *
     * @exception JMSException general exception if JMS implementation fails to
     *                         get the Exception listener for this Connection.
     */

    ExceptionListener 
    getExceptionListener() throws JMSException;


    /** Set an exception listener for this connection.
      *
      * <P>If a JMS provider detects a serious problem with a connection it 
      * will inform the connection's ExceptionListener if one has been 
      * registered. It does this by calling the listener's onException() 
      * method passing it a JMSException describing the problem.
      *
      * <P>This allows a client to be asynchronously notified of a problem. 
      * Some connections only consume messages so they would have no other 
      * way to learn their connection has failed.
      *
      * <P>A Connection serializes execution of its ExceptionListener.
      *
      * <P>A JMS provider should attempt to resolve connection problems 
      * itself prior to notifying the client of them.
      *
      * @param handler the exception listener.
      *
      * @exception JMSException general exception if JMS implementation fails to
      *                         set the Exception listener for this Connection.
      */

    void 
    setExceptionListener(ExceptionListener listener) throws JMSException;

    /** Start (or restart) a Connection's delivery of incoming messages.
      * Starting a started session is ignored.
      *  
      * @exception JMSException if JMS implementation fails to start the
      *                         message delivery due to some internal error.
      *
      * @see javax.jms.Connection#stop
      */

    void
    start() throws JMSException;

 
    /** Used to temporarily stop a Connection's delivery of incoming messages.
      * It can be restarted using its <CODE>start</CODE> method. When stopped,
      * delivery to all the Connection's message consumers is inhibited: 
      * synchronous receive's block and messages are not delivered to message 
      * listeners.
      *
      * <P>This call blocks until receives and/or message listeners in progress
      * have completed.
      *
      * <P>Stopping a Session has no affect on its ability to send messages. 
      * Stopping a stopped session is ignored.
      *
      * <P>A stop method call must not return until delivery of messages has
      * paused. This means a client can rely on the fact that none of its
      * message listeners will be called and all threads of control waiting
      * for receive to return will not return with a message until the
      * connection is restarted. The receive timers for a stopped connection
      * continue to advance so receives may time out while the connection is
      * stopped.
      * 
      * <P>If MessageListeners are running when stop is invoked, stop must
      * wait until all of them have returned before it may return. While these
      * MessageListeners are completing, they must have full services of the
      * connection available to them.
      *  
      * @exception JMSException if JMS implementation fails to stop the
      *                         message delivery due to some internal error.
      *
      * @see javax.jms.Connection#start
      */

    void
    stop() throws JMSException;

 
    /** Since a provider typically allocates significant resources outside 
      * the JVM on behalf of a Connection, clients should close them when 
      * they are not needed. Relying on garbage collection to eventually 
      * reclaim these resources may not be timely enough.
      *
      * <P>There is no need to close the sessions, producers, and consumers
      * of a closed connection.
      *
      * <P>When this method is invoked it should not return until message
      * processing has been orderly shut down. This means that all message 
      * listeners that may have been running have returned and that all pending 
      * receives have returned. A close terminates all pending message receives 
      * on the connection's sessions' consumers. The receives may return with a 
      * message or null depending on whether there was a message or not available 
      * at the time of the close. If one or more of the connection's sessions' 
      * message listeners is processing a message at the point connection 
      * close is invoked, all the facilities of the connection and it's sessions 
      * must remain available to those listeners until they return control to the 
      * JMS provider. 
      *
      * <P>Closing a connection causes any of its sessions' in-process
      * transactions to be rolled back. In the case where a session's
      * work is coordinated by an external transaction manager, when
      * using XASession, a session's commit and rollback methods are
      * not used and the result of a closed session's work is determined
      * later by a transaction manager.
      *
      * Closing a connection does NOT force an 
      * acknowledge of client acknowledged sessions. 
      * 
      * <P>Invoking the session acknowledge method on a closed connection's 
      * session must throw a JMSException. Closing a closed connection must 
      * NOT throw an exception.
      *  
      * @exception JMSException if JMS implementation fails to close the
      *                         connection due to internal error. For 
      *                         example, a failure to release resources
      *                         or to close socket connection can lead
      *                         to throwing of this exception.
      *
      */

    void 
    close() throws JMSException; 
}
