/*
 * @(#)InvalidClientIDException.java	1.5 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/**
 * <P> This exception must be thrown when a 
 *     client attempts to set a connection's client id to a value that 
 *     is rejected by a provider.
 *
 * @version     26 August 1998
 * @author      Rahul Sharma
 **/

public class InvalidClientIDException extends JMSException {

  /** Construct a InvalidClientIDException with reason and errorCode 
   *  for exception
   *
   *  @param  reason        a description of the exception
   *  @param  errorCode     a string specifying the vendor specific
   *                        error code
   *                        
   **/
  public 
  InvalidClientIDException(String reason, String errorCode) {
    super(reason, errorCode);
  }

  /** Construct a InvalidClientIDException with reason. Error code defaults to 
   *  null.
   *
   *  @param  reason        a description of the exception
   **/
  public 
  InvalidClientIDException(String reason) {
    super(reason);
  }

}
