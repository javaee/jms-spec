/*
 * @(#)XATopicSession.java	1.9 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** An XATopicSession provides a regular TopicSession which can be used to
  * create TopicSubscribers and TopicPublishers (optional).
  *
  * @version     1.0 - 14 May 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.XASession
  * @see         javax.jms.TopicSession
  */

public interface XATopicSession extends XASession {

    /** Get the topic session associated with this XATopicSession.
      *   
      * @return the topic session object. 
      *   
      * @exception JMSException if a JMS error occurs.
      */  
  
    TopicSession 
    getTopicSession() throws JMSException;
}
