/*
 * @(#)ExceptionListener.java	1.5 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;


/** If a JMS provider detects a serious problem with a Connection it will 
  * inform the Connection's ExceptionListener if one has been registered. 
  * It does this by calling the listener's onException() method passing it a 
  * JMSException describing the problem.
  *
  * <P>This allows a client to be asynchronously notified of a problem. 
  * Some Connections only consume messages so they would have no other way 
  * to learn their Connection has failed.
  *
  * <P>A JMS provider should attempt to resolve connection problems 
  * themselves prior to notifying the client of them.
  *
  * @version     1.0 - 9 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see javax.jms.Connection#setExceptionListener(ExceptionListener)
  */

public interface ExceptionListener {

    /** Notify user of a JMS exception.
      *
      * @param exception the JMS exception.
      */

    void 
    onException(JMSException exception);
}
