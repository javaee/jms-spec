/*
 * @(#)MessageProducer.java	1.17 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** A client uses a message producer to send messages to a Destination. It is 
  * created by passing a Destination to a create message producer method 
  * supplied by a Session.
  *
  * <P>A client also has the option of creating a message producer without 
  * supplying a Destination. In this case, a Destination must be input on 
  * every send operation. A typical use for this style of message producer is
  * to send replies to requests using the request's replyTo Destination.
  *
  * <P>A client can specify a default delivery mode, priority and time-to-live 
  * for messages sent by a message producer. It can also specify delivery 
  * mode, priority and time-to-live per message.
  *
  * <P>A client can specify a time-to-live value in milliseconds for each
  * message it sends. This value defines a message expiration time which
  * is the sum of the message's time-to-live and the GMT it is sent (for
  * transacted sends, this is the time the client sends the message, not
  * the time the transaction is committed).
  *
  * <P>A JMS provider should do its best to accurately expire messages;
  * however, JMS does not define the accuracy provided.
  *
  * @version     1.0 - 3 August 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.TopicPublisher
  * @see         javax.jms.QueueSender
  * @see         javax.jms.Session
  */

public interface MessageProducer {

    /** Set whether message IDs are disabled.
      *  
      * <P>Since message ID's take some effort to create and increase a
      * message's size, some JMS providers may be able to optimize message
      * overhead if they are given a hint that message ID is not used by
      * an application. JMS message Producers provide a hint to disable
      * message ID. When a client sets a Producer to disable message ID
      * they are saying that they do not depend on the value of message
      * ID for the messages it produces. These messages must either have
      * message ID set to null or, if the hint is ignored, messageID must
      * be set to its normal unique value.
      *
      * <P>Message IDs are enabled by default.
      *
      * @param value indicates if message IDs are disabled.
      *  
      * @exception JMSException if JMS fails to set disabled message
      *                         Id due to some internal error.
      */ 

    void
    setDisableMessageID(boolean value) throws JMSException;


    /** Get an indication of whether message IDs are disabled.
      *  
      * @return an indication of whether message IDs are disabled.
      *  
      * @exception JMSException if JMS fails to get disabled message
      *                         Id due to some internal error.
      */ 

    boolean 
    getDisableMessageID() throws JMSException;


    /** Set whether message timestamps are disabled.
      *  
      * <P>Since timestamps take some effort to create and increase a 
      * message's size, some JMS providers may be able to optimize message 
      * overhead if they are given a hint that timestamp is not used by an 
      * application. JMS message Producers provide a hint to disable 
      * timestamps. When a client sets a producer to disable timestamps 
      * they are saying that they do not depend on the value of timestamp 
      * for the messages it produces. These messages must either have 
      * timestamp set to null or, if the hint is ignored, timestamp must 
      * be set to its normal value.
      *  
      * <P>Message timestamps are enabled by default.
      *
      * @param value indicates if message timestamps are disabled.
      *  
      * @exception JMSException if JMS fails to set disabled message
      *                         timestamp due to some internal error.
      */ 

    void
    setDisableMessageTimestamp(boolean value) throws JMSException;


    /** Get an indication of whether message timestamps are disabled.
      *  
      * @return an indication of whether message IDs are disabled.
      *  
      * @exception JMSException if JMS fails to get disabled message
      *                         timestamp due to some internal error.
      */ 

    boolean
    getDisableMessageTimestamp() throws JMSException;


    /** Set the producer's default delivery mode.
      *  
      * <P>Delivery mode is set to PERSISTENT by default.
      *
      * @param deliveryMode the message delivery mode for this message
      * producer. Legal values are <code>DeliveryMode.NON_PERSISTENT</code>
      * or <code>DeliveryMode.PERSISTENT</code>.
      *  
      * @exception JMSException if JMS fails to set delivery mode
      *                         due to some internal error.          
      *
      * @see javax.jms.MessageProducer#getDeliveryMode
      * @see javax.jms.DeliveryMode#NON_PERSISTENT
      * @see javax.jms.DeliveryMode#PERSISTENT
      * @see javax.jms.Message#DEFAULT_DELIVERY_MODE
      */ 

    void
    setDeliveryMode(int deliveryMode) throws JMSException;


    /** Get the producer's default delivery mode.
      *  
      * @return the message delivery mode for this message producer.
      *  
      * @exception JMSException if JMS fails to get delivery mode
      *                         due to some internal error.
      *
      * @see javax.jms.MessageProducer#setDeliveryMode
      */ 

    int 
    getDeliveryMode() throws JMSException;


    /** Set the producer's default priority.
      *  
      * <P>JMS defines a 10 level priority value with 0 as the lowest 
      * and 9 as the highest. Clients should consider 0-4 as 
      * gradients of normal priority and 5-9 as gradients of expedited 
      * priority. Priority is set to 4, by default.
      *
      * @param priority the message priority for this message producer.
      *                 Priority must be a value between 0 and 9.
      * 
      *  
      * @exception JMSException if JMS fails to set priority
      *                         due to some internal error.
      *
      * @see javax.jms.MessageProducer#getPriority
      * @see javax.jms.Message#DEFAULT_PRIORITY
      */ 

    void
    setPriority(int defaultPriority) throws JMSException;


    /** Get the producer's default priority.
      *  
      * @return the message priority for this message producer.
      *  
      * @exception JMSException if JMS fails to get priority
      *                         due to some internal error.
      *
      * @see javax.jms.MessageProducer#setPriority
      */ 

    int 
    getPriority() throws JMSException;


    /** Set the default length of time in milliseconds from its dispatch time
      * that a produced message should be retained by the message system.
      *
      * <P>Time to live is set to zero by default.
      *
      * @param timeToLive the message time to live in milliseconds; zero is
      * unlimited
      *
      * @exception JMSException if JMS fails to set Time to Live
      *                         due to some internal error.
      *
      * @see javax.jms.MessageProducer#getTimeToLive
      * @see javax.jms.Message#DEFAULT_TIME_TO_LIVE
      */
   
    void
    setTimeToLive(long timeToLive) throws JMSException;
   
   
    /** Get the default length of time in milliseconds from its dispatch time
      * that a produced message should be retained by the message system.
      *
      * @return the message time to live in milliseconds; zero is unlimited
      *
      * @exception JMSException if JMS fails to get Time to Live
      *                         due to some internal error.
      *
      * @see javax.jms.MessageProducer#setTimeToLive
      */ 
 
    long
    getTimeToLive() throws JMSException;


    /** Since a provider may allocate some resources on behalf of a
      * MessageProducer outside the JVM, clients should close them when they
      * are not needed. Relying on garbage collection to eventually reclaim
      * these resources may not be timely enough.
      *  
      * @exception JMSException if JMS fails to close the producer
      *                         due to some error.
      */ 

    void
    close() throws JMSException;
}
