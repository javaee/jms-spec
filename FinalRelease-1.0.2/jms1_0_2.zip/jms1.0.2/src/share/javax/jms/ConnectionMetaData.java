/*
 * @(#)ConnectionMetaData.java	1.8 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

import java.util.Enumeration;

/** ConnectionMetaData provides information describing the Connection.
  *
  * @version     1.0 - 13 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  */

public interface ConnectionMetaData {

    /** Get the JMS version.
      *
      * @return the JMS version.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the meta-data
      *                         retrieval.
      */

    String 
    getJMSVersion() throws JMSException;


    /** Get the JMS major version number.
      *  
      * @return the JMS major version number.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the meta-data
      *                         retrieval.
      */

    int 
    getJMSMajorVersion() throws JMSException; 
 

    /** Get the JMS minor version number.
      *  
      * @return the JMS minor version number.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the meta-data
      *                         retrieval.
      */

    int  
    getJMSMinorVersion() throws JMSException;


    /** Get the JMS provider name.
      *
      * @return the JMS provider name.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the meta-data
      *                         retrieval.
      */ 

    String 
    getJMSProviderName() throws JMSException;


    /** Get the JMS provider version.
      *
      * @return the JMS provider version.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the meta-data
      *                         retrieval.
      */ 

    String 
    getProviderVersion() throws JMSException;


    /** Get the JMS provider major version number.
      *  
      * @return the JMS provider major version number.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the meta-data
      *                         retrieval.
      */

    int
    getProviderMajorVersion() throws JMSException; 

 
    /** Get the JMS provider minor version number.
      *  
      * @return the JMS provider minor version number.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the meta-data
      *                         retrieval.
      */

    int  
    getProviderMinorVersion() throws JMSException;

 
    /** Get an enumeration of JMSX Property Names.
      *  
      * @return an Enumeration of JMSX PropertyNames.
      *  
      * @exception JMSException if some internal error occurs in
      *                         JMS implementation during the property
      *                         names retrieval.
      */

    Enumeration
    getJMSXPropertyNames() throws JMSException;
}
