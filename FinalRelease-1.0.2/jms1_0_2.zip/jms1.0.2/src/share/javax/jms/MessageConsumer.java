/*
 * @(#)MessageConsumer.java	1.11 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** A client uses a message consumer to receive messages from a Destination.
  * It is created by passing a Destination to a create message consumer method 
  * supplied by a Session.
  *
  * <P>The parent interface for all message consumers.
  *
  * <P>A message consumer can be created with a message selector. This allows 
  * the client to restrict the messages delivered to the message consumer to 
  * those that match the selector.
  *
  * <P>A client may either synchronously receive a message consumer's messages 
  * or have the consumer asynchronously deliver them as they arrive.
  *
  * <P>A client can request the next message from a message consumer using one 
  * of its receive methods. There are several variations of receive that allow a 
  * client to poll or wait for the next message.
  *
  * <P>A client can register a MessageListener object with a message consumer. 
  * As messages arrive at the message consumer, it delivers them by calling the 
  * MessageListener's onMessage method.
  *
  * <P>It is a client programming error for a MessageListener to throw an 
  * exception.
  *
  * @version     1.0 - 13 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.QueueReceiver
  * @see         javax.jms.TopicSubscriber
  * @see         javax.jms.Session
  */

public interface MessageConsumer {

    /** Get this message consumer's message selector expression.
      *  
      * @return this message consumer's message selector
      *  
      * @exception JMSException if JMS fails to get message
      *                         selector due to some JMS error
      */ 

    String
    getMessageSelector() throws JMSException;


    /** Get the message consumer's MessageListener.
      *  
      * @return the listener for the message consumer, or null if there isn't
      * one set.
      *  
      * @exception JMSException if JMS fails to get message
      *                         listener due to some JMS error
      * @see javax.jms.MessageConsumer#setMessageListener
      */ 

    MessageListener
    getMessageListener() throws JMSException;


    /** Set the message consumer's MessageListener.
      * 
      * <P>Setting the message listener to null is the equivalent of 
      * unsetting the message listener for the message consumer.
      *
      * <P>Calling the setMessageListener method of MessageConsumer
      * while messages are being consumed by an existing listener
      * or the consumer is being used to synchronously consume messages
      * is undefined.
      *  
      * @param messageListener the messages are delivered to this listener
      *  
      * @exception JMSException if JMS fails to set message
      *                         listener due to some JMS error
      * @see javax.jms.MessageConsumer#getMessageListener
      */ 

    void
    setMessageListener(MessageListener listener) throws JMSException;


    /** Receive the next message produced for this message consumer.
      *  
      * <P>This call blocks indefinitely until a message is produced
      * or until this message consumer is closed.
      *
      * <P>If this receive is done within a transaction, the message
      * remains on the consumer until the transaction commits.
      *  
      * @exception JMSException if JMS fails to receive the next
      *                         message due to some error.
      *  
      * @return the next message produced for this message consumer, or 
      * null if this message consumer is concurrently closed.
      * 
      */ 
 
    Message
    receive() throws JMSException;


    /** Receive the next message that arrives within the specified
      * timeout interval.
      *  
      * <P>This call blocks until a message arrives, the
      * timeout expires, or this message consumer is closed.
      * A timeout of zero never expires and the call blocks indefinitely.
      *
      * @param timeout the timeout value (in milliseconds)
      *
      * @exception JMSException if JMS fails to receive the next
      *                         message due to some error.
      * @return the next message produced for this message consumer, or 
      * return null if timeout expires or message consumer concurrently closed.
      */ 

    Message
    receive(long timeout) throws JMSException;


    /** Receive the next message if one is immediately available.
      *  
      * @exception JMSException if JMS fails to receive the next
      *                         message due to some error.
      * @return the next message produced for this message consumer, or 
      * null if one is not available.
      */ 

    Message
    receiveNoWait() throws JMSException;


    /** Since a provider may allocate some resources on behalf of a
      * MessageConsumer outside the JVM, clients should close them when they
      * are not needed. Relying on garbage collection to eventually reclaim
      * these resources may not be timely enough.
      *
      * <P>This call blocks until a receive or message listener in progress
      * has completed. A blocked message consumer receive call 
      * returns null when this message consumer is closed.
      *  
      * @exception JMSException if JMS fails to close the consumer
      *                         due to some error.
      */ 

    void
    close() throws JMSException;
}
