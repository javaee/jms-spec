/*
 * @(#)XATopicConnection.java	1.12 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** An XATopicConnection provides the same create options as TopicConnection (optional).
  * The only difference is that an XAConnection is by definition transacted.
  *
  * @version     1.0 - 13 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.XAConnection
  */

public interface XATopicConnection 
	extends XAConnection, TopicConnection {

    /** Create an XATopicSession.
      *  
      * @exception JMSException if JMS Connection fails to create a
      *                         XA topic session due to some internal error.
      */ 

    XATopicSession
    createXATopicSession() throws JMSException;

    /** Create an XATopicSession
      *  
      * @param transacted      ignored.
      * @param acknowledgeMode ignored.
      *  
      * @return a newly created XA topic session.
      *  
      * @exception JMSException if JMS Connection fails to create a
      *                         XA topic session due to some internal error.
      */ 

    TopicSession
    createTopicSession(boolean transacted,
                       int acknowledgeMode) throws JMSException;
}
