/*
 * @(#)TemporaryTopic.java	1.8 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** A TemporaryTopic is a unique Topic object created for the duration of 
  * a TopicConnection. It is a system defined Topic that can only be 
  * consumed by the TopicConnection that created it.
  *
  * @version     1.0 - 9 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see TopicSession#createTemporaryTopic()
  */

public interface TemporaryTopic extends Topic {

    /** Delete this temporary topic. If there are still existing publishers
      * or subscribers still using it, then a JMSException will be thrown.
      *  
      * @exception JMSException if JMS implementation fails to delete a 
      *                         Temporary queue due to some internal error.
      */

    void 
    delete() throws JMSException; 
}
