/*
 * @(#)QueueReceiver.java	1.18 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;


/** A client uses a QueueReceiver for receiving messages that have been 
  * delivered to a queue.
  *
  * <P>Although it is possible to have multiple QueueReceivers for the same queue, 
  * JMS does not define how messages are distributed between the QueueReceivers.
  *
  * @version     1.0 - 9 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.QueueSession#createReceiver(Queue, String)
  * @see         javax.jms.QueueSession#createReceiver(Queue)
  * @see         javax.jms.MessageConsumer
  */

public interface QueueReceiver extends MessageConsumer {

    /** Get the queue associated with this queue receiver.
      *  
      * @return the queue 
      *  
      * @exception JMSException if JMS fails to get queue for
      *                         this queue receiver
      *                         due to some internal error.
      */ 
 
    Queue
    getQueue() throws JMSException;
}
