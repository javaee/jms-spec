/*
 * @(#)ServerSessionPool.java	1.9 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** A ServerSessionPool is an object implemented by an application server 
  * to provide a pool of ServerSessions for processing the messages of a 
  * ConnectionConsumer (optional).
  *
  * <P>Its only method is <CODE>getServerSession</CODE>. JMS does not 
  * architect how the pool is implemented. It could be a static pool of 
  * ServerSessions or it could use a sophisticated algorithm to dynamically 
  * create ServerSessions as needed.
  *
  * <P>If the ServerSessionPool is out of ServerSessions, the 
  * <CODE>getServerSession</CODE> call may block. If a ConnectionConsumer 
  * is blocked, it cannot deliver new messages until a ServerSession is 
  * eventually returned.
  *
  * @version     1.0 - 9 March 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see javax.jms.ServerSession
  */

public interface ServerSessionPool {

    /** Return a server session from the pool.
      *
      * @return a server session from the pool.
      *  
      * @exception JMSException if an application server fails to
      *                         return a Server Session out of its
      *                         server session pool.
      */ 

    ServerSession
    getServerSession() throws JMSException;
}
