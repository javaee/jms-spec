/*
 * @(#)IllegalStateException.java	1.4 99/11/03
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/**
 * <P> This exception is thrown when a method is 
 *     invoked at an illegal or inappropriate time or if the provider is 
 *     not in an appropriate state for the requested operation. For example, 
 *     this exception should be thrown if Session.commit() is called on a 
 *     non-transacted session.
 *
 * @version     26 August 1998
 * @author      Rahul Sharma
 **/

public class IllegalStateException extends JMSException {

  /** Construct a IllegalStateException with reason and errorCode 
   *  for exception
   *
   *  @param  reason        a description of the exception
   *  @param  errorCode     a string specifying the vendor specific
   *                        error code
   *                        
   **/
  public 
  IllegalStateException(String reason, String errorCode) {
    super(reason, errorCode);
  }

  /** Construct a IllegalStateException with reason. Error code 
   *  defaults to null.
   *
   *  @param  reason        a description of the exception
   **/
  public 
  IllegalStateException(String reason) {
    super(reason);
  }

}
